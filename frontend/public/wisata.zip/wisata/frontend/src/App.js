import { useEffect, useState } from 'react';
import { Outlet, RouterProvider, createBrowserRouter, useNavigate } from 'react-router-dom';
import NavbarMenu from '@components/Navbar';
import Footer from '@components/Footer';
import Home from '@pages/Home';
import Login from '@pages/Login';
import Register from '@pages/Register';
import Detail from '@pages/Detail';
import Reservation from '@pages/Reservation';

const Layout = () => {
  return (
    <>
      <NavbarMenu />
      <Outlet />
      <Footer />
    </>
  );
};

const ProtectedRoute = ({ element }) => {
  const navigate = useNavigate();
  useEffect(() => {
    const user = localStorage.getItem('user');
    if (!user) {
      navigate('/login');
    }
  }, [navigate]);
  return element;
};

const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />,
    children: [
      {
        path: "/",
        element: <ProtectedRoute element={<Home />} />,
      },
      {
        path: "/detail/:id",
        element: <ProtectedRoute element={<Detail />} />,
      },
      {
        path: "/user/reservations",
        element: <ProtectedRoute element={<Reservation />} />,
      },
      {
        path: "/login",
        element: <Login />,
      },
      {
        path: "/register",
        element: <Register />,
      },
    ],
  },
]);

function App() {
  return (
    <div>
      <RouterProvider router={router} />
    </div>
  )
}

export default App;

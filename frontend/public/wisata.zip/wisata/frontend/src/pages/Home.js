/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Card, Container, Row, Col, Spinner, Alert, Button, Form } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const Home = () => {
    const [attractions, setAttractions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [query, setQuery] = useState('');
    const [limit] = useState(10);

    useEffect(() => {
        const fetchAttractions = async () => {
            const options = {
                method: 'GET',
                headers: {
                    accept: 'application/json',
                    Authorization: 'fsq3dbxiaTnl+vzgPdgPrHycRwnDhoJXRAyVEYv07Mf9oHM='
                }
            };
            const url = `https://api.foursquare.com/v3/places/search?ll=-7.393215%2C110.234210&radius=92000&limit=50&query=${query}`;

            try {
                const response = await axios.get(url, options);
                setAttractions(response.data.results);
                setLoading(false);
            } catch (err) {
                setError('Error fetching tourist attractions.');
                setLoading(false);
            }
        };

        fetchAttractions();
    }, [query]);

    const handleSearch = (e) => {
        e.preventDefault();
        setQuery(e.target.search.value);
    };

    if (loading) {
        return (
            <Container className="d-flex justify-content-center align-items-center" style={{ height: '100vh' }}>
                <Spinner animation="border" />
            </Container>
        );
    }

    if (error) {
        return (
            <Container className="mt-5">
                <Alert variant="danger">{error}</Alert>
            </Container>
        );
    }

    return (
        <Container>
            <h2 className="mt-3 text-center">Daftar Tempat Wisata / Kuliner</h2>
            <Form onSubmit={handleSearch} className="d-flex justify-content-center mt-4">
                <Form.Control type="text" name="search" placeholder="Cari tempat wisata..." className="me-2" />
                <Button type="submit">Cari</Button>
            </Form>
            <Row xs={1} md={2} className="g-4 mt-5">
                {attractions.map(attraction => (
                    <Col key={attraction.fsq_id} md={4} className="mb-4">
                        <Card style={{ width: '18rem', height: '18rem' }}>
                            {/* <Card.Img variant="top" src={attraction.categories[0].icon.prefix} /> */}
                            <Card.Subtitle className="mb-2 text-muted p-3">{attraction.categories.map(category => category.name).join(', ')}</Card.Subtitle>
                            <Card.Body>
                                <Card.Title>{attraction.name}</Card.Title>
                                <Card.Text>{attraction.location.formatted_address}</Card.Text>
                                <Link to={'/detail/' + attraction.fsq_id}>
                                    <Button variant="primary">Lihat</Button>
                                </Link>
                            </Card.Body>
                        </Card>
                    </Col>
                ))}
            </Row>
        </Container>
    );
};

export default Home;

import React, { useState } from 'react';
import { Button, Form, Alert, Card, Container } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

const Register = () => {
    const [phone, setPhone] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (event) => {
        event.preventDefault();
        setError('');
        try {
            const response = await axios.post('http://localhost:5000/register', {
                phone,
                password
            });

            if (response.status === 200) {
                navigate('/');
            }
        } catch (error) {
            if (error.response) {
                setError(error.response.data.message);
            } else if (error.request) {
                setError('No response from server. Please try again later.');
            } else {
                setError('An error occurred. Please try again.');
            }
        }
    };

    return (
        <Container className="d-flex justify-content-center align-items-center min-vh-100">
            <Card className="p-4 shadow-lg" style={{ maxWidth: '400px', width: '100%' }}>
                <Card.Body>
                    <Card.Title className="text-center mb-4">
                        <img className="mb-4" src="https://getbootstrap.com/docs/5.3/assets/brand/bootstrap-logo.svg" alt="" width="72" height="57" />
                        <h1 className="h3 mb-3 fw-normal">Daftar</h1>
                    </Card.Title>
                    <Form onSubmit={handleSubmit}>
                        <Form.Group className="mb-3" controlId="phone">
                            <Form.Label>No Telpon</Form.Label>
                            <Form.Control
                                type="text"
                                placeholder="0813xxxx"
                                value={phone}
                                onChange={(e) => setPhone(e.target.value)}
                            />
                            <Form.Text className="text-muted">
                                Input No Telpon Anda.
                            </Form.Text>
                        </Form.Group>

                        <Form.Group className="mb-3" controlId="password">
                            <Form.Label>Password</Form.Label>
                            <Form.Control
                                type="password"
                                placeholder="Password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                            />
                        </Form.Group>

                        {error && <Alert variant="danger">{error}</Alert>}

                        <Button variant="primary" type="submit" className="w-100 mb-3">
                            Register
                        </Button>

                        <div className="text-center">
                            <Link to="/login">
                                <Button variant="info" type="button" className="w-100 mb-3">
                                    Login
                                </Button>
                            </Link>
                        </div>
                    </Form>
                </Card.Body>
            </Card>
        </Container>
    );
};

export default Register;

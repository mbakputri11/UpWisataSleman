/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Container, Card, Spinner, Alert, Carousel, ListGroup, Form, Button } from 'react-bootstrap';
import Map from '@components/Map';
import ReservationModal from '@components/ReservationModal';

const Detail = () => {
    const { id } = useParams();
    const [detail, setDetail] = useState(null);
    const [photos, setPhotos] = useState([]);
    const [reviews, setReviews] = useState([]);
    const [trainSchedule, setTrainSchedule] = useState([]);
    const [filteredSchedule, setFilteredSchedule] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [origin, setOrigin] = useState('');
    const [destination, setDestination] = useState('');
    const [selectedTrain, setSelectedTrain] = useState(null);
    const [showModal, setShowModal] = useState(false);
    const [placeName, setPlaceName] = useState('');
    const [reservationData, setReservationData] = useState({
        name: '',
        gender: '',
        age: ''
    });
    const user = JSON.parse(localStorage.getItem('user'));
    const navigate = useNavigate();

    useEffect(() => {
        const options = {
            method: 'GET',
            headers: {
                accept: 'application/json',
                Authorization: 'fsq3dbxiaTnl+vzgPdgPrHycRwnDhoJXRAyVEYv07Mf9oHM='
            }
        };

        const fetchDetail = async () => {
            try {
                const response = await axios.get(`https://api.foursquare.com/v3/places/${id}`, options);
                setDetail(response.data);
                setPlaceName(response.data.name); // Set nama tempat untuk modal
            } catch (err) {
                setError('Error fetching place details.');
            }
        };

        const fetchPhotos = async () => {
            try {
                const response = await axios.get(`https://api.foursquare.com/v3/places/${id}/photos`, options);
                setPhotos(response.data);
            } catch (err) {
                console.error('Error fetching photos:', err);
            }
        };

        const fetchReviews = async () => {
            try {
                const response = await axios.get(`https://api.foursquare.com/v3/places/${id}/tips`, options);
                setReviews(response.data);
            } catch (err) {
                console.error('Error fetching reviews:', err);
            }
        };

        const loadTrainSchedule = async () => {
            try {
                const response = await fetch('/tiketkereta.json'); // Path sesuai dengan letak file di folder public
                const data = await response.json();
                return data;
            } catch (err) {
                console.error('Error loading train schedule:', err);
                return [];
            }
        };

        const fetchAllData = async () => {
            setLoading(true);
            await fetchDetail();
            await fetchPhotos();
            await fetchReviews();
            const schedule = await loadTrainSchedule();
            setTrainSchedule(schedule);
            setLoading(false);
        };

        fetchAllData();
    }, [id]);

    useEffect(() => {
        if (origin && destination) {
            const filtered = trainSchedule.filter(
                (train) => train.asal.toLowerCase() === origin.toLowerCase() && train.tujuan.toLowerCase() === destination.toLowerCase()
            );
            setFilteredSchedule(filtered);
        }
    }, [origin, destination, trainSchedule]);

    const handleSelectTrain = (train) => {
        setSelectedTrain(train);
        setShowModal(true);
    };

    const handleCloseModal = () => {
        setShowModal(false);
    };


    if (loading) {
        return (
            <Container className="d-flex justify-content-center align-items-center" style={{ height: '100vh' }}>
                <Spinner animation="border" />
            </Container>
        );
    }

    if (error) {
        return (
            <Container className="mt-5">
                <Alert variant="danger">{error}</Alert>
            </Container>
        );
    }

    return (
        <Container className="mt-5">
            {photos.length > 0 && (
                <Carousel>
                    {photos.map((photo, index) => (
                        <Carousel.Item key={index}>
                            <img
                                className="d-block w-100"
                                src={`${photo.prefix}original${photo.suffix}`}
                                alt={`Slide ${index + 1}`}
                            />
                        </Carousel.Item>
                    ))}
                </Carousel>
            )}

            {detail && (
                <Card className="mt-3 mb-4">
                    <Card.Body>
                        <Card.Title>{detail.name}</Card.Title>
                        <Card.Text>
                            <strong>Lokasi:</strong> {detail.location.formatted_address}, {detail.location.locality}, {detail.location.region}
                        </Card.Text>
                        <Card.Text>
                            <strong>Jenis:</strong> {detail.categories.map(category => category.name).join(', ')}
                        </Card.Text>
                        <Card.Text>
                            <strong>Deskripsi:</strong> {detail.description || '-'}
                        </Card.Text>
                    </Card.Body>
                </Card>
            )}

            {detail && (
                <Map endLocation={`${detail.geocodes.main.latitude},${detail.geocodes.main.longitude}`} />
            )}

            <h3 className="mt-5">Select Train Schedule</h3>
            <Form className="mt-3">
                <Form.Group controlId="formOrigin">
                    <Form.Label>Asal</Form.Label>
                    <Form.Control as="select" value={origin} onChange={(e) => setOrigin(e.target.value)}>
                        <option value="">Pilih Asal</option>
                        <option value="jakarta">Jakarta</option>
                        {/* Tambahkan opsi lain sesuai kebutuhan */}
                    </Form.Control>
                </Form.Group>
                <Form.Group controlId="formDestination" className="mt-3">
                    <Form.Label>Tujuan</Form.Label>
                    <Form.Control as="select" value={destination} onChange={(e) => setDestination(e.target.value)}>
                        <option value="">Pilih Tujuan</option>
                        <option value="yogyakarta">Yogyakarta</option>
                        <option value="solo">Solo</option>
                        {/* Tambahkan opsi lain sesuai kebutuhan */}
                    </Form.Control>
                </Form.Group>
            </Form>

            {filteredSchedule.length > 0 ? (
                <ListGroup className="mt-3">
                    {filteredSchedule.map((train, index) => (
                        <ListGroup.Item key={index}>
                            <Card>
                                <Card.Body>
                                    <Card.Title>{train.nama}</Card.Title>
                                    <Card.Text>
                                        <strong>Jenis:</strong> {train.jenis}
                                    </Card.Text>
                                    <Card.Text>
                                        <strong>Harga:</strong> {train.harga}
                                    </Card.Text>
                                    <Card.Text>
                                        <strong>Waktu Awal:</strong> {train.waktu_awal}
                                    </Card.Text>
                                    <Card.Text>
                                        <strong>Waktu Akhir:</strong> {train.waktu_akhir}
                                    </Card.Text>
                                    <Card.Text>
                                        <strong>Durasi:</strong> {train.durasi}
                                    </Card.Text>
                                    <Button variant="primary" onClick={() => handleSelectTrain(train)}>
                                        Pilih
                                    </Button>
                                </Card.Body>
                            </Card>
                        </ListGroup.Item>
                    ))}
                </ListGroup>
            ) : (
                <Alert variant="info" className="mt-3">Tidak ada jadwal kereta</Alert>
            )}

            <ReservationModal
                show={showModal}
                handleClose={handleCloseModal}
                trainData={selectedTrain}
                placeName={placeName}
                user={user.id}
            />
        </Container>
    );
};

export default Detail;

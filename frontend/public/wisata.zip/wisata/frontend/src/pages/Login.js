import CardDefault from '@components/CardDefault'
import React, { useState } from 'react'
import { Form, Button, Alert, Card, Container } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios'

const Login = () => {
    const [phone, setPhone] = useState('')
    const [password, setPassword] = useState('')
    const [error, setError] = useState('')
    const navigate = useNavigate()

    const handleSubmit = async (event) => {
        event.preventDefault()
        setError('')
        try {
            const response = await axios.post('http://localhost:5000/login', {
                phone,
                password
            })

            if (response.status === 200) {
                localStorage.setItem('user', JSON.stringify(response.data.user));
                navigate('/')
            }
        } catch (error) {
            if (error.response) {
                setError(error.response.data.message)
            } else if (error.request) {
                setError('No response from server. Please try again later.')
            } else {
                setError('An error occurred. Please try again.')
            }
        }
    }

    return (
        <>
            <Container className="d-flex justify-content-center align-items-center min-vh-100">
                <Card className="p-4 shadow-lg border-0" style={{ maxWidth: '400px', width: '100%' }}>
                    <Card.Body>
                        <Card.Title className="text-center mb-4">
                            <img className="mb-4" src="https://getbootstrap.com/docs/5.3/assets/brand/bootstrap-logo.svg" alt="" width="72" height="57" />
                            <h1 className="h3 mb-3 fw-normal">Login</h1>
                        </Card.Title>
                        <Form onSubmit={handleSubmit}>
                            <Form.Group className="mb-3" controlId="phone">
                                <Form.Label>No Telpon</Form.Label>
                                <Form.Control
                                    type="text"
                                    placeholder="0813xxxx"
                                    value={phone}
                                    onChange={(e) => setPhone(e.target.value)}
                                />
                                <Form.Text className="text-muted">
                                    Input No Telpon Anda.
                                </Form.Text>
                            </Form.Group>

                            <Form.Group className="mb-3" controlId="password">
                                <Form.Label>Password</Form.Label>
                                <Form.Control
                                    type="password"
                                    placeholder="Password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                />
                            </Form.Group>

                            {error && <Alert variant="danger">{error}</Alert>}

                            {/* <div className="d-flex justify-content-between align-items-center mb-3">
                                <Form.Check type="checkbox" label="Remember me" />
                                <Link to="/forgot-password">Forgot Password?</Link>
                            </div> */}

                            <Button variant="primary" type="submit" className="w-100 mb-3">
                                Login
                            </Button>

                            <div className="text-center">
                                <Link to="/register">
                                    <Button variant="info" type="button" className="w-100 mb-3">
                                        Register
                                    </Button>
                                </Link>
                            </div>
                        </Form>
                    </Card.Body>
                </Card>
            </Container>
        </>
    )
}

export default Login;

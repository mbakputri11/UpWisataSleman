/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Card, Container, Row, Col, Spinner, Alert, Button } from 'react-bootstrap';

const Reservation = () => {
    const [reservations, setReservations] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchReservations = async () => {
            const user = JSON.parse(localStorage.getItem('user'));
            const user_id = user.id;

            try {
                const response = await axios.get('http://localhost:5000/reservation', {
                    params: { user_id }
                });
                setReservations(response.data);
                setLoading(false);
            } catch (err) {
                setError('Error fetching reservations.');
                setLoading(false);
            }
        };

        fetchReservations();
    }, []);

    if (loading) {
        return (
            <Container className="d-flex justify-content-center align-items-center" style={{ height: '100vh' }}>
                <Spinner animation="border" />
            </Container>
        );
    }

    if (error) {
        return (
            <Container className="mt-5">
                <Alert variant="danger">{error}</Alert>
            </Container>
        );
    }

    return (
        <Container>
            <h2 className="mt-3 text-center">Reservasi Saya</h2>
            <Row xs={1} md={2} className="g-4 mt-5">
                {reservations.map(reservation => (
                    <Col key={reservation.id} md={4} className="mb-4">
                        <Card style={{ width: '18rem', height: '18rem' }}>
                            <Card.Body>
                                <Card.Title>{reservation.train_name}</Card.Title>
                                <Card.Text>Nama: {reservation.name}</Card.Text>
                                <Card.Text>Gender: {reservation.gender}</Card.Text>
                                <Card.Text>Usia: {reservation.age}</Card.Text>
                                <Card.Text>Harga: {reservation.price}</Card.Text>
                                <Card.Text>Durasi: {reservation.duration}</Card.Text>
                                <Card.Text>Lokasi: {reservation.location}</Card.Text>
                            </Card.Body>
                        </Card>
                    </Col>
                ))}
            </Row>
        </Container>
    )
}

export default Reservation
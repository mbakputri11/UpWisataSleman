import React from 'react';
import { Navbar, Nav, Container } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';

const NavbarMenu = () => {
    const navigate = useNavigate();
    const user = JSON.parse(localStorage.getItem('user'));

    const handleLogout = () => {
        localStorage.removeItem('user');
        navigate('/login');
    };

    return (
        <Navbar bg="light" expand="lg">
            <Container className="container-fluid">
                <Navbar.Brand href="/">Wisata App</Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="me-auto">
                        <Nav.Link as={Link} to="/">Home</Nav.Link>
                    </Nav>
                    <div className="d-flex">
                        {user && (
                            <>
                                <Nav.Link as={Link} to="/user/reservations" className="me-4">Reservasi Saya</Nav.Link>
                                {/* <Nav.Link className="me-4">{user.username}</Nav.Link> */}
                                <Nav.Link onClick={handleLogout} className="me-4">Logout</Nav.Link>
                            </>
                        )}
                        {!user && (
                            <>
                                <Nav.Link as={Link} to="/login" className="me-4">Login</Nav.Link>
                                <Nav.Link as={Link} to="/register" className="me-4">Register</Nav.Link>
                            </>
                        )}
                    </div>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    );
};

export default NavbarMenu;

/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMapEvents, LayersControl } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet-routing-machine';
import 'leaflet-routing-machine/dist/leaflet-routing-machine.css';
import RoutingControl from './RoutingControl';

const maps = {
    base: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
};

const iconA = L.icon({
    iconUrl: 'https://cdn-icons-png.flaticon.com/512/252/252025.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
});

const geocode = async (address) => {
    const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${address}`);
    const data = await response.json();
    if (data.length > 0) {
        const { lat, lon } = data[0];
        return [parseFloat(lat), parseFloat(lon)];
    }
    return null;
};

const ClickHandler = ({ setStartCoords }) => {
    useMapEvents({
        click(e) {
            setStartCoords([e.latlng.lat, e.latlng.lng]);
        }
    });
    return null;
};

const Map = ({ endLocation }) => {
    const [map, setMap] = useState(null);
    const [startCoords, setStartCoords] = useState(null);
    const [endCoords, setEndCoords] = useState(null);

    useEffect(() => {
        const fetchCoords = async () => {
            const end = await geocode(endLocation);
            setEndCoords(end);
        };
        fetchCoords();
    }, [endLocation]);

    if (!endCoords) return <p>Loading map...</p>;

    return (
        <MapContainer center={endCoords} zoom={13} style={{ height: '500px', width: '100%' }} whenCreated={map => setMap(map)}>
            <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            />
            <ClickHandler setStartCoords={setStartCoords} />
            {startCoords && (
                <>
                    <RoutingControl
                        position={'topleft'}
                        start={startCoords}
                        end={endCoords}
                        color={'#757de8'}
                    />
                    <Marker position={startCoords}>
                        <Popup>Start Location</Popup>
                    </Marker>
                </>
            )}
            <Marker position={endCoords}>
                <Popup>End Location</Popup>
            </Marker>
            <LayersControl position="topright">
                <LayersControl.BaseLayer checked name="Map">
                    <TileLayer
                        attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
                        url={maps.base}
                    />
                </LayersControl.BaseLayer>
            </LayersControl>
        </MapContainer>
    );
};

export default Map;

/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import React from 'react'
import Card from 'react-bootstrap/Card';

const CardDefault = ({ title, bodyClass = "", containerClass = "", children }) => {
    return (
        <Card className={"border-0 shadow-sm rounded " + containerClass}>
            <Card.Title>{title}</Card.Title>
            <Card.Body className={bodyClass ?? ''}>{children}</Card.Body>
        </Card>
    )
}

export default CardDefault
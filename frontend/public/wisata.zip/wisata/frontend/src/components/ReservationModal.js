/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from 'react';
import { Modal, Button, Form } from 'react-bootstrap';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const ReservationModal = ({ show, handleClose, trainData, placeName, user }) => {
    const [reservationData, setReservationData] = useState({
        name: '',
        gender: '',
        age: '',
        train: trainData || null,
        location: placeName || '',
        user_id: user || null
    });

    const navigate = useNavigate();

    // Update reservationData when trainData or placeName change
    useEffect(() => {
        setReservationData(prevData => ({
            ...prevData,
            train: trainData || null,
            location: placeName || '',
            user_id: user || null
        }));
    }, [trainData, placeName, user]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setReservationData({
            ...reservationData,
            [name]: value
        });
    };

    const handleReservationSubmit = async () => {
        try {
            await axios.post('http://localhost:5000/reservation', reservationData);
            navigate('/');
        } catch (err) {
            console.log(err);
        }

        // Reset form and close modal
        handleClose();
    };

    return (
        <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
                <Modal.Title>Reservation Form - {placeName}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Form>
                    <Form.Group controlId="formName">
                        <Form.Label>Nama</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Masukan nama"
                            name="name"
                            value={reservationData.name}
                            onChange={handleInputChange}
                        />
                    </Form.Group>
                    <Form.Group controlId="formGender">
                        <Form.Label>Jenis Kelamin</Form.Label>
                        <Form.Control
                            as="select"
                            name="gender"
                            value={reservationData.gender}
                            onChange={handleInputChange}
                        >
                            <option value="">Pilih Jenis Kelamin</option>
                            <option value="Laki - Laki">Laki - Laki</option>
                            <option value="Perempuan">Perempuan</option>
                        </Form.Control>
                    </Form.Group>
                    <Form.Group controlId="formAge">
                        <Form.Label>Umur</Form.Label>
                        <Form.Control
                            type="number"
                            placeholder="Masukan umur"
                            name="age"
                            value={reservationData.age}
                            onChange={handleInputChange}
                        />
                    </Form.Group>
                </Form>
            </Modal.Body>
            <Modal.Footer>
                <Button variant="secondary" onClick={handleClose}>
                    Tutup
                </Button>
                <Button variant="primary" onClick={handleReservationSubmit}>
                    Simpan
                </Button>
            </Modal.Footer>
        </Modal>
    );
};

export default ReservationModal;

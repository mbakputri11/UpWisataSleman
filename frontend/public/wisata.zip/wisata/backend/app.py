from flask import Flask, request, jsonify, make_response
from flask_sqlalchemy import SQLAlchemy
from flask_restful import Api, Resource, reqparse
from flask_cors import CORS
from flask_bcrypt import generate_password_hash, check_password_hash
import os
from werkzeug.utils import secure_filename

# Initialize the application
app = Flask(__name__)
api = Api(app)

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:@localhost/kontak'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize extensions
db = SQLAlchemy(app)
CORS(app)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)

class Reservation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    gender = db.Column(db.String(50), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    train_name = db.Column(db.String(100), nullable=False)
    train_type = db.Column(db.String(100), nullable=False)
    price = db.Column(db.String(50), nullable=False)
    start_time = db.Column(db.String(50), nullable=False)
    end_time = db.Column(db.String(50), nullable=False)
    duration = db.Column(db.String(50), nullable=False)
    location = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    user = db.relationship('User', back_populates='reservations')

User.reservations = db.relationship('Reservation', back_populates='user', cascade='all, delete-orphan')

class ReservationResource(Resource):
    def post(self):
        data = request.json
        
        if not data:
            return make_response(jsonify({'message': 'No data provided'}), 400)
        
        try:
            user_id = data['user_id']
            name = data['name']
            gender = data['gender']
            age = data['age']
            train_name = data['train']['nama']
            train_type = data['train']['jenis']
            price = data['train']['harga']
            start_time = data['train']['waktu_awal']
            end_time = data['train']['waktu_akhir']
            duration = data['train']['durasi']
            location = data['location']
            
            new_reservation = Reservation(
                user_id=user_id,
                name=name,
                gender=gender,
                age=age,
                train_name=train_name,
                train_type=train_type,
                price=price,
                start_time=start_time,
                end_time=end_time,
                duration=duration,
                location=location
            )
            
            db.session.add(new_reservation)
            db.session.commit()
            
            return make_response(jsonify({'message': 'Reservation created successfully'}), 200)
        except Exception as e:
            return make_response(jsonify({'message': 'Error creating reservation', 'error': str(e)}), 500)
    
    def get(self):
        user_id = request.args.get('user_id')
        reservations = Reservation.query.filter_by(user_id=user_id).all()
        result = []
        for reservation in reservations:
            res = {
                'id': reservation.id,
                'name': reservation.name,
                'gender': reservation.gender,
                'age': reservation.age,
                'train_name': reservation.train_name,
                'train_type': reservation.train_type,
                'price': reservation.price,
                'start_time': reservation.start_time,
                'end_time': reservation.end_time,
                'duration': reservation.duration,
                'location': reservation.location,
            }
            result.append(res)
        return make_response(jsonify(result), 200)


class UserResource(Resource):
    def post(self):
        data = request.json

        
        if 'phone' not in data or 'password' not in data:
            response = jsonify({'message': 'No telpon atau password wajib diisi!'})
            return make_response(response, 400)
        
        phone = data['phone']
        password = data['password']
        
        # Encrypt password before saving
        hashed_password = generate_password_hash(password)
        
        # Create new user object
        new_user = User(username=phone, password=hashed_password)
        
        # Save user data to database
        db.session.add(new_user)
        db.session.commit()
        
        response = jsonify({'message': 'Register berhasil!'})
        return make_response(response, 200)
    
class LoginResource(Resource):
    def post(self):
        data = request.json

        if 'phone' not in data or 'password' not in data:
            response = jsonify({'message': 'No telpon atau password wajib diisi!'})
            return make_response(response, 400)

        phone = data['phone']
        password = data['password']

        user = User.query.filter_by(username=phone).first()

        if user and check_password_hash(user.password, password):
            user_data = {
                'id': user.id,
                'username': user.username,
            }
            response = jsonify({'message': 'Login berhasil!', 'user': user_data})
            return make_response(response, 200)
        else:
            response = jsonify({'message': 'No telpon atau password salah!'})
            return make_response(response, 401)

        
api.add_resource(UserResource, '/register')
api.add_resource(LoginResource, '/login')
api.add_resource(ReservationResource, '/reservation')

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)

import React, { useState, useEffect } from "react";
import SecondaryHeader from "../components/SecondaryHeader";
import Pemeringkatan from "../components/Pemeringkatan";
import Detail from "../components/Detail";

function Perhitungan() {
  const [alternatives, setAlternatives] = useState([]);
  const [criteria, setCriteria] = useState([]);
  const [matrix, setMatrix] = useState([]);
  const [weights, setWeights] = useState([]);
  const [selectedAlternatives, setSelectedAlternatives] = useState([]);
  const [showResults, setShowResults] = useState(false);
  const [normalizedMatrix, setNormalizedMatrix] = useState([]);
  const [weightedMatrix, setWeightedMatrix] = useState([]);
  const [optimumValues, setOptimumValues] = useState([]);
  const [rankings, setRankings] = useState([]);
  const [showDetail, setShowDetail] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      const response = await fetch("http://localhost:5000/penilaian");
      const data = await response.json();

      const rawAlternatives = data.map(item => item.alternatif).filter((alt, index, self) => self.indexOf(alt) === index);
      const rawMatrix = data.map(item => [item.C1, item.C2, item.C3, item.C4, item.C5]);

      // Always include A0 in the alternatives and matrix
      const maxValues = rawMatrix[0].map((_, colIndex) =>
        Math.max(...rawMatrix.map(row => row[colIndex]))
      );

      setAlternatives(["A0", ...rawAlternatives]);
      setMatrix([maxValues, ...rawMatrix]);

      const criteriaResponse = await fetch("http://localhost:5000/kriteria");
      const criteriaData = await criteriaResponse.json();
      setCriteria(criteriaData.map(item => item.nama));
      setWeights(criteriaData.map(item => item.bobot));
      setSelectedAlternatives(new Array(rawAlternatives.length + 1).fill(false));
    };

    fetchData();
  }, []);

  const handleCheckboxChange = (index) => {
    const updatedSelection = [...selectedAlternatives];
    updatedSelection[index] = !updatedSelection[index];
    setSelectedAlternatives(updatedSelection);
  };

  const handleSelectAllChange = (event) => {
    const isChecked = event.target.checked;
    const nonA0AlternativesCount = alternatives.length - 1; // Exclude A0
    const updatedSelection = new Array(nonA0AlternativesCount + 1).fill(false);
    updatedSelection[0] = false; // A0 should not be selected
    for (let i = 1; i <= nonA0AlternativesCount; i++) {
      updatedSelection[i] = isChecked;
    }
    setSelectedAlternatives(updatedSelection);
  };

  const handleHitungClick = () => {
    const selectedMatrix = matrix.filter((_, index) => {
      const alt = alternatives[index];
      return alt !== "A0" && selectedAlternatives[index];
    });

    if (selectedMatrix.length === 0) {
      alert("Please select at least one alternative.");
      return;
    }

    const normalize = normalizeMatrix(matrix);
    setNormalizedMatrix(normalize);

    const weightedMatrix = weightedNormalization(normalize, weights);
    setWeightedMatrix(weightedMatrix);

    const optimumValues = calculateOptimum(weightedMatrix);
    setOptimumValues(optimumValues);

    const rankings = calculateRankings(optimumValues, alternatives);
    setRankings(rankings);

    setShowResults(true);
  };

  const normalizeMatrix = (matrix) => {
    const columnSums = matrix.reduce((sums, row) => {
      row.forEach((value, index) => {
        sums[index] = (sums[index] || 0) + value;
      });
      return sums;
    }, []);

    return matrix.map(row => row.map((val, colIndex) => val / columnSums[colIndex]));
  };

  const weightedNormalization = (normalizedMatrix, weights) => {
    return normalizedMatrix.map(row => row.map((val, i) => val * weights[i]));
  };

  const calculateOptimum = (weightedMatrix) => {
    return weightedMatrix.map(row => row.reduce((sum, val) => sum + val, 0));
  };

  const calculateRankings = (optimumValues, alternatives) => {
    return optimumValues
      .map((value, index) => ({ alternative: alternatives[index], value }))
      .sort((a, b) => b.value - a.value);
  };

  return (
    <>
      <SecondaryHeader
        sectitle="Rekomendasi Pemberian Bantuan Pengembangan Desa Wisata"
        secdesc="Pilih desa wisata yang ingin Anda evaluasi untuk mendapatkan rekomendasi pemberian bantuan pengembangan. Sistem akan menghitung berdasarkan kriteria yang telah ditentukan dan memberikan rekomendasi terbaik untuk pengembangan desa wisata tersebut."
      />
      <br />
      <div className="container section-title" data-aos="fade-up">
        <h3>Perhitungan menggunakan Metode ARAS</h3>
      </div>
      <div className="container section-description">
        <p className="table-description">Silakan pilih desa wisata yang akan dihitung untuk evaluasi.</p>
      </div>

      <div className="container">
        <table className="table table-bordered">
        <thead>
            <tr>
              <th rowSpan="2">No</th>
              <th rowSpan="2">Nama Desa Wisata</th>
              <th colSpan="5" className="text-center">Kriteria</th>
              <th rowSpan="2">Pilih</th>
            </tr>
            <tr>
              <th>Kelembagaan & SDM</th>
              <th>Amenitas</th>
              <th>Digital</th>
              <th>Daya Tarik Wisata</th>
              <th>Resiliensi</th>
            </tr>
          </thead>
          <tbody>
            {alternatives.map((alt, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{alt}</td>
                {matrix[index] && matrix[index].map((val, colIndex) => (
                  <td key={colIndex}>{val}</td>
                ))}
                <td>
                  <input
                    type="checkbox"
                    checked={selectedAlternatives[index] || false}
                    onChange={() => handleCheckboxChange(index)}
                    disabled={alt === "A0"} // Disable checkbox for A0
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="d-flex justify-content-end">
          <label>
            <input
              type="checkbox"
              onChange={handleSelectAllChange}
              checked={selectedAlternatives.length > 0 && selectedAlternatives.slice(1).every((selected) => selected)} // Check all except A0
            /> Pilih Semua
          </label>
        </div>
        <div className="container section-title" data-aos="fade-up">
          <button
            className="btn_all btn-sm col-sm-2 col-4"
            onClick={handleHitungClick}
          >
            Hitung
          </button>
        </div>
      </div>
      {showResults && optimumValues.length > 0 && (
  <div>
    <Pemeringkatan optimumValues={optimumValues} alternatives={alternatives} />
    <div className="container section-title">
      <button
        className="btn_all btn-sm col-sm-2 col-4"
        onClick={() => setShowDetail(!showDetail)}
      >
        {showDetail ? "Tutup Detail" : "Lihat Detail"}
      </button>
    </div>
    {showDetail && (
      <Detail
        alternatives={alternatives}
        criteria={criteria}
        matrix={matrix}
        normalizedMatrix={normalizedMatrix}
        weightedMatrix={weightedMatrix}
        optimumValues={optimumValues}
        rankings={rankings}
      />
    )}
        </div>
      )}
    </>
  );
}

export default Perhitungan;

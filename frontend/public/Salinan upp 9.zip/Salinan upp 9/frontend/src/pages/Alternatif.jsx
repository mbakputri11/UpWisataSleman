import React, { useState, useEffect } from "react";
import SecondaryHeader from "../components/SecondaryHeader";
import { Modal } from "react-bootstrap";

function Alternatif() {
  const [showModal, setShowModal] = useState(false);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [alternatifs, setAlternatifs] = useState([]);
  const [newAlternatif, setNewAlternatif] = useState({
    kode: "", // Added kode field
    nama: "",
    klasifikasi: "berkembang",
  });
  const [updateAlternatif, setUpdateAlternatif] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchAlternatifs = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch("http://127.0.0.1:5000/alternatif");
      if (!response.ok) {
        throw new Error("Failed to fetch data");
      }
      const data = await response.json();
      setAlternatifs(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAlternatifs();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    try {
      const response = await fetch("http://127.0.0.1:5000/alternatif", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newAlternatif),
      });
      if (!response.ok) {
        throw new Error("Failed to add alternatif");
      }
      await fetchAlternatifs();
      setShowModal(false);
      setNewAlternatif({
        kode: "",
        nama: "",
        klasifikasi: "berkembang",
      });
    } catch (err) {
      setError(err.message);
    }
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    setError(null);
    try {
      const response = await fetch(
        `http://127.0.0.1:5000/alternatif/${updateAlternatif.id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(updateAlternatif),
        }
      );
      if (!response.ok) {
        throw new Error("Failed to update alternatif");
      }
      await fetchAlternatifs();
      setShowUpdateModal(false);
      setUpdateAlternatif(null);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this alternatif?")) {
      setLoading(true);
      setError(null);
      try {
        const response = await fetch(`http://127.0.0.1:5000/alternatif/${id}`, {
          method: "DELETE",
        });
        if (!response.ok) {
          throw new Error("Failed to delete alternatif");
        }
        await fetchAlternatifs();
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }
  };

  const openUpdateModal = (alternatif) => {
    setUpdateAlternatif(alternatif);
    setShowUpdateModal(true);
  };

  return (
    <>
      <SecondaryHeader
        sectitle="Data Desa Wisata"
        secdesc="Silakan lengkapi data desa wisata berikut untuk dilakukan analisis
            dan perhitungan. Data yang Anda input akan digunakan sebagai dasar
            dalam menentukan prioritas dan pemberian bantuan pengembangan"
      />
      <section id="alternatif" className="alternatif">
        <div className="container section-title" data-aos="fade-up">
          <button
            className="btn_all btn-sm col-sm-2 col-4"
            onClick={() => setShowModal(true)}
          >
            Tambah Desa Wisata
          </button>
        </div>

        <Modal show={showModal} onHide={() => setShowModal(false)}>
          <Modal.Header closeButton>
            <Modal.Title>Input Desa Wisata</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label htmlFor="kode" className="form-label">
                  Kode
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="kode"
                  value={newAlternatif.kode}
                  onChange={(e) =>
                    setNewAlternatif({ ...newAlternatif, kode: e.target.value })
                  }
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="namaDesa" className="form-label">
                  Nama Desa Wisata
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="namaDesa"
                  value={newAlternatif.nama}
                  onChange={(e) =>
                    setNewAlternatif({ ...newAlternatif, nama: e.target.value })
                  }
                  required
                />
              </div>
              
              <div className="mb-3">
                <label htmlFor="klasifikasi" className="form-label">
                  Klasifikasi
                </label>
                <select
                  className="form-select"
                  id="klasifikasi"
                  value={newAlternatif.klasifikasi}
                  onChange={(e) =>
                    setNewAlternatif({
                      ...newAlternatif,
                      klasifikasi: e.target.value,
                    })
                  }
                >
                  <option value="berkembang">Berkembang</option>
                  <option value="maju">Maju</option>
                  <option value="mandiri">Mandiri</option>
                </select>
              </div>
              <button
                type="submit"
                className="btn btn-primary"
                disabled={loading}
              >
                {loading ? "Submitting..." : "Submit"}
              </button>
              {error && <div className="alert alert-danger mt-2">{error}</div>}
            </form>
          </Modal.Body>
        </Modal>

        <Modal show={showUpdateModal} onHide={() => setShowUpdateModal(false)}>
          <Modal.Header closeButton>
            <Modal.Title>Update Desa Wisata</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            {updateAlternatif && (
              <form onSubmit={handleUpdate}>
                <div className="mb-3">
                  <label htmlFor="updateKode" className="form-label">
                    Kode
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="updateKode"
                    value={updateAlternatif.kode}
                    onChange={(e) =>
                      setUpdateAlternatif({
                        ...updateAlternatif,
                        kode: e.target.value,
                      })
                    }
                    required
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="updateNamaDesa" className="form-label">
                    Nama Desa Wisata
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="updateNamaDesa"
                    value={updateAlternatif.nama}
                    onChange={(e) =>
                      setUpdateAlternatif({
                        ...updateAlternatif,
                        nama: e.target.value,
                      })
                    }
                    required
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="updateKlasifikasi" className="form-label">
                    Klasifikasi
                  </label>
                  <select
                    className="form-select"
                    id="updateKlasifikasi"
                    value={updateAlternatif.klasifikasi}
                    onChange={(e) =>
                      setUpdateAlternatif({
                        ...updateAlternatif,
                        klasifikasi: e.target.value,
                      })
                    }
                  >
                    <option value="berkembang">Berkembang</option>
                    <option value="maju">Maju</option>
                    <option value="mandiri">Mandiri</option>
                  </select>
                </div>
                <button
                  type="submit"
                  className="btn btn-primary"
                  disabled={loading}
                >
                  {loading ? "Updating..." : "Update"}
                </button>
                {error && (
                  <div className="alert alert-danger mt-2">{error}</div>
                )}
              </form>
            )}
          </Modal.Body>
        </Modal>

        <div className="container mt-4">
          {loading ? (
            <div>Loading...</div>
          ) : (
            <table className="table table-striped">
              <thead>
                <tr>
                  <th>Kode</th>
                  <th>Nama Desa Wisata</th>
                  <th>Klasifikasi</th>
                  <th className="text-nowrap w-10">Aksi</th>
                </tr>
              </thead>
              <tbody>
                {alternatifs.map((alternatif) => (
                  <tr key={alternatif.id}>
                    <td>{alternatif.kode}</td>
                    <td>{alternatif.nama}</td>
                    <td>{alternatif.klasifikasi}</td>
                    <td
                      style={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                      }}
                    >
                      <div style={{ display: "flex", gap: "10px" }}>
                        <button
                          className="btn btn-warning btn-sm"
                          onClick={() => openUpdateModal(alternatif)}
                        >
                          Update
                        </button>
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={() => handleDelete(alternatif.id)}
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </section>
    </>
  );
}

export default Alternatif;

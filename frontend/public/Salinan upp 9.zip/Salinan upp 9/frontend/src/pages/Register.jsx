import React, { useState } from "react";
import axios from "axios";

function Register() {
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [error, setError] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      setError("Passwords do not match");
      return; // Correct placement of return
    }
    try {
      const response = await axios.post("http://localhost:5000/register", {
        username: formData.username,
        password: formData.password,
      });
      console.log("Registration successful:", response.data);
      // Handle successful registration (e.g., redirect to login page)
      // Example: window.location.href = "/login"; // Uncomment this line to redirect
    } catch (err) {
      setError(err.response?.data?.message || "Registration failed");
      console.error("Registration error:", err);
    }
  };

  return (
    <div className="login-page">
      {/* Bagian Gambar */}
      <div className="login-image">
        <img
          src="assets/img/ornamen.png"
          alt="Pariwisata"
          className="image-full"
        />
      </div>

      {/* Bagian Form */}
      <div className="login-form-container">
        <div className="form-header">
          <h3>
 Sistem Pendukung Keputusan
            <br />
            Pemberian Bantuan Pengembangan Objek Pariwisata
          </h3>
          <img
            src="assets/img/logo-sleman.png"
            alt="UpDestination Logo"
            className="logo"
          />
        </div>
        <form className="login-form" onSubmit={handleSubmit}>
          <h3>Daftar Akun</h3>
          {error && <p className="error">{error}</p>}

          {/* Username Input */}
          <div className="input-group">
            <label htmlFor="username">Username</label>
            <input
              type="text"
              id="username"
              name="username"
              placeholder="Masukkan username"
              value={formData.username}
              onChange={handleChange}
              required
            />
          </div>

        

          {/* Password Input */}
          <div className="input-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              placeholder="Masukkan password"
              value={formData.password}
              onChange={handleChange}
              required
            />
          </div>

          {/* Confirm Password Input */}
          <div className="input-group">
            <label htmlFor="confirmPassword">Konfirmasi Password</label>
            <input
              type="password"
              id="confirmPassword"
              name="confirmPassword"
              placeholder="Konfirmasi password"
              value={formData.confirmPassword}
              onChange={handleChange}
              required
            />
          </div>

          <button type="submit" className="btn-login btn-primary">
            Daftar
          </button>
          <p className="form-footer">
            Sudah punya akun? 
          </p>
          <p className="link-register">
            <a href="/">Masuk sekarang</a>
          </p>
        </form>
      </div>
    </div>
  );
}

export default Register;
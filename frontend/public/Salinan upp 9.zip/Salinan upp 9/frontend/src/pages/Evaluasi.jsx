import React, { useState, useEffect } from "react";
import { Modal } from "react-bootstrap";
import SecondaryHeader from "../components/SecondaryHeader";

function Evaluasi() {
  const [showModal, setShowModal] = useState(false);
  const [selectedDesa, setSelectedDesa] = useState("");
  const [kode, setKode] = useState("");
  const [nilaiKriteria, setNilaiKriteria] = useState({
    kelembagaan: "",
    amenitas: "",
    digital: "",
    dayaTarik: "",
    resiliensi: "",
  });
  const [evaluasiList, setEvaluasiList] = useState([]);
  const [isEditing, setIsEditing] = useState(false);
  const [currentEvaluasiId, setCurrentEvaluasiId] = useState(null);

  const desaWisataList = [
    "Turgo-Merapi",
    "Mina Wisata Bokesan",
    "Bulak Sawah",
    "Pengklik",
    "Kerajinan Bambu Brajan",
    "Sedjarah Kelor",
    "Bromonilan",
    "Lingkungan Sukunan",
    "Brayut",
    "Plosokuning",
  ];

  const toggleModal = () => {
    setShowModal(!showModal);
    if (showModal) resetForm();
  };

  const resetForm = () => {
    setSelectedDesa("");
    setKode("");
    setNilaiKriteria({
      kelembagaan: "",
      amenitas: "",
      digital: "",
      dayaTarik: "",
      resiliensi: "",
    });
    setIsEditing(false);
    setCurrentEvaluasiId(null);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNilaiKriteria((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newPenilaian = {
      kode,
      alternatif: selectedDesa,
      C1: nilaiKriteria.kelembagaan,
      C2: nilaiKriteria.amenitas,
      C3: nilaiKriteria.digital,
      C4: nilaiKriteria.dayaTarik,
      C5: nilaiKriteria.resiliensi,
    };

    const endpoint = isEditing
      ? `http://localhost:5000/penilaian/${currentEvaluasiId}`
      : "http://localhost:5000/penilaian";

    const method = isEditing ? "PUT" : "POST";

    fetch(endpoint, {
      method,
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(newPenilaian),
    })
      .then((response) => response.json())
      .then(() => {
        fetchEvaluasi();
        toggleModal();
      })
      .catch((error) => console.error("Error:", error));
  };

  const fetchEvaluasi = () => {
    fetch("http://localhost:5000/penilaian")
      .then((response) => response.json())
      .then((data) => setEvaluasiList(data))
      .catch((error) => console.error("Error fetching evaluations:", error));
  };

  const handleEdit = (evaluasi) => {
    setSelectedDesa(evaluasi.alternatif);
    setKode(evaluasi.kode);
    setNilaiKriteria({
      kelembagaan: evaluasi.C1,
      amenitas: evaluasi.C2,
      digital: evaluasi.C3,
      dayaTarik: evaluasi.C4,
      resiliensi: evaluasi.C5,
    });
    setCurrentEvaluasiId(evaluasi.id);
    setIsEditing(true);
    toggleModal();
  };

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this evaluation?")) {
      fetch(`http://localhost:5000/penilaian/${id}`, {
        method: "DELETE",
      })
        .then(() => fetchEvaluasi())
        .catch((error) => console.error("Error deleting evaluation:", error));
    }
  };

  useEffect(() => {
    fetchEvaluasi();
  }, []);

  return (
    <>
      <SecondaryHeader sectitle="PENILAIAN" secdesc="Halaman ini memungkinkan Anda untuk memberikan
       penilaian terhadap masing-masing kriteria yang telah ditetapkan untuk setiap desa wisata.
        Penilaian ini akan digunakan untuk mengevaluasi dan menentukan desa wisata yang layak menerima 
        dukungan pengembangan. Masukkan nilai sesuai dengan kriteria yang telah ditentukan untuk menjaga objektivitas dan keakuratan analisis." />
      <section id="evaluasi" className="evaluasi">
      <div className="container section-title text-center" data-aos="fade-up">
        <button
          className="btn_all btn-sm col-sm-2 col-4"
          onClick={toggleModal}
        >
          Tambah Penilaian
        </button>
      </div>

      <Modal show={showModal} onHide={toggleModal}>
        <Modal.Header closeButton>
          <Modal.Title>{isEditing ? "Update Penilaian Desa Wisata" : "Input Penilaian Desa Wisata"}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label htmlFor="kode" className="form-label">Kode</label>
              <input
                type="text"
                className="form-control"
                name="kode"
                value={kode}
                onChange={(e) => setKode(e.target.value)}
                required
              />
            </div>
            <div className="mb-3">
              <label htmlFor="desaWisata" className="form-label">Pilih Desa Wisata</label>
              <select
                id="desaWisata"
                className="form-select"
                value={selectedDesa}
                onChange={(e) => setSelectedDesa(e.target.value)}
              >
                <option value="">Pilih Desa Wisata</option>
                {desaWisataList.map((desa, index) => (
                  <option key={index} value={desa}>
                    {desa}
                  </option>
                ))}
              </select>
            </div>
            {["kelembagaan", "amenitas", "digital", "dayaTarik", "resiliensi"].map((item, index) => (
              <div key={index} className="mb-3">
                <label className="form-label">{item.charAt(0).toUpperCase() + item.slice(1)}</label>
                <input
                  type="number"
                  className="form-control"
                  name={item}
                  value={nilaiKriteria[item]}
                  onChange={handleChange}
                  min="0"
                  max="50"
                />
              </div>
            ))}
            <button type="submit" className="btn btn-primary">
              {isEditing ? "Update" : "Submit"}
            </button>
          </form>
        </Modal.Body>
      </Modal>

      <div className="container mt-4">
        <table className="table table-bordered">
          <thead>
            <tr>
              <th>Kode</th>
              <th>Nama Desa Wisata</th>
              <th>Kelembagaan & SDM</th>
              <th>Amenitas</th>
              <th>Digital</th>
              <th>Daya Tarik Wisata</th>
              <th>Resiliensi</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            {evaluasiList.map((evaluasi) => (
              <tr key={evaluasi.id}>
                <td>{evaluasi.kode || evaluasi.alternatif}</td>
                <td>{evaluasi.alternatif}</td>
                <td>{evaluasi.C1}</td>
                <td>{evaluasi.C2}</td>
                <td>{evaluasi.C3}</td>
                <td>{evaluasi.C4}</td>
                <td>{evaluasi.C5}</td>
                <td style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
                  <button
                    className="btn btn-warning btn-sm"
                    onClick={() => handleEdit(evaluasi)}
                  >
                    Update
                  </button>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => handleDelete(evaluasi.id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      </section>
    </>
  );
}

export default Evaluasi;

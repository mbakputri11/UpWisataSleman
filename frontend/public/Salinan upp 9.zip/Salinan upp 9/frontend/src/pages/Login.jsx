import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom"; // Import useNavigate

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate(); // Initialize useNavigate

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:5000/login", {
        username,
        password,
      });

      console.log("Login response:", response.data); // Log the response data

      // Check if the login was successful
      if (response.data.message === 'Login successful') {
        // Navigate to home on successful login without alert
        navigate("/home"); 
      } else {
        alert(response.data.message); // Show error message if login fails
      }
    } catch (err) {
      // Handle errors
      if (err.response) {
        // The request was made and the server responded with a status code
        console.error("Response data:", err.response.data);
        alert(err.response.data.message || "An error occurred");
      } else if (err.request) {
        // The request was made but no response was received
        console.error("Request data:", err.request);
        alert("No response from server");
      } else {
        // Something happened in setting up the request that triggered an Error
        console.error("Error message:", err.message);
        alert("Error in setting up request");
      }
    }
  };

  return (
    <div className="login-page">
      {/* Bagian Gambar */}
      <div className="login-image">
        <img src="assets/img/ornamen.png" alt="Pariwisata" className="image-full" />
      </div>

      {/* Bagian Form */}
      <div className="login-form-container">
        <div className="form-header">
          <h3>
            Sistem Pendukung Keputusan<br />
            Pemberian Bantuan Pengembangan Objek Pariwisata
          </h3>
          <img src="assets/img/logo-sleman.png" alt="UpDestination Logo" className="logo" />
        </div>
        <form className="login-form" onSubmit={handleSubmit}>
          <h3>Login</h3>
          <div className="input-group">
            <label htmlFor="username">Username</label>
            <input
              type="text"
              id="username"
              name="username"
              placeholder="Masukkan username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          <div className="input-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              placeholder="Masukkan password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="btn-login btn-primary">
            Masuk
          </button>
          <p className="form-footer">
            Belum punya akun? 
          </p>
          <p className="link-register">
            <a href="/register">Daftar sekarang</a>
          </p>
        </form>
      </div>
    </div>
  );
}

export default Login;
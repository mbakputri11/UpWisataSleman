import React from 'react';

const Pemeringkatan = ({ optimumValues, alternatives }) => {
  // Get the optimum value of A0 for Ki calculation
  const a0Value = optimumValues[0]; // Assuming A0 is the first element

  // Calculate Ki values and create a ranking array
  const rankings = optimumValues.map((value, index) => ({
    kode: `A${index}`, // Kode alternatif
    nama: index === 0 ? 'NULL' : alternatives[index], // Ganti dengan nama desa yang sesuai
    nilaiFungsiOptimum: value,
    ki: (value / a0Value).toFixed(3), // Calculate Ki
    rank: index === 0 ? '-' : null // Set rank A0 to '-' and others will be calculated later
  }));

  // Sort rankings based on nilaiFungsiOptimum in descending order
  rankings.sort((a, b) => b.nilaiFungsiOptimum - a.nilaiFungsiOptimum);

  // Add ranking based on sorted order for alternatives other than A0
  rankings.forEach((ranking, index) => {
    if (ranking.kode !== 'A0') {
      ranking.rank = index; // Assign rank based on sorted order
    }
  });

  return (
    <div>
      <h3 className="section-title">Rangkings</h3>
      <div className="container">
        <table className="table table-bordered">
          <thead>
            <tr>
              <th>Kode</th>
              <th>Nama Alternatif</th>
              <th>Nilai Fungsi Optimum</th>
              <th>Ki</th>
              <th>Ranking</th>
            </tr>
          </thead>
          <tbody>
            {rankings.map((ranking) => (
              <tr key={ranking.kode}>
                <td>{ranking.kode}</td> {/* Menampilkan kode alternatif */}
                <td>{ranking.nama}</td> {/* Menampilkan nama alternatif */}
                <td>{ranking.nilaiFungsiOptimum.toFixed(4)}</td>
                <td>{ranking.ki}</td>
                <td>{ranking.rank}</td> {/* Menampilkan ranking */}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Pemeringkatan;
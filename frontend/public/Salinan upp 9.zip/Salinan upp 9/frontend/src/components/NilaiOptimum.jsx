import React from 'react';

const NilaiOptimum = ({ optimumValues }) => {
  // Get the optimum value of A0 for Ki calculation
  const a0Value = optimumValues[0]; // Assuming A0 is the first element

  return (
    <div>
      <h3 className="section-title">Nilai Fungsi Optimum (S)</h3>
      <div className="container section-description">
        <p className="table-description">
          Nilai fungsi optimum S dihitung menggunakan persamaan ARA-07 untuk
          masing-masing alternatif dengan cara menjumlahkan nilai-nilai pada
          matriks data ternormalisasi terbobot (D) yang telah dihitung
          sebelumnya
        </p>
      </div>
      <div className="container">
        <table className="table">
          <thead>
            <tr>
              <th>Alternatif</th>
              <th>Nilai Fungsi Optimum</th>
              <th>Ki</th> {/* New column for Ki */}
            </tr>
          </thead>
          <tbody>
            {optimumValues.map((value, index) => (
              <tr key={index}>
                <td>{`A${index}`}</td> {/* Display A0, A1, A2, ... */}
                <td>{value.toFixed(3)}</td> {/* Display with three decimal places */}
                <td>{(value / a0Value).toFixed(3)}</td> {/* Calculate Ki */}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default NilaiOptimum;
import React from 'react';

const NormalisasiTerbobot = ({ weightedMatrix }) => {
  return (
    <div>
      <h3 className="section-title">Matriks Normalisasi Terbobot (D)</h3>
      <div className="container section-description">
        <p className="table-description">
          Data matriks normalisasi (R) dari proses sebelumnya selanjutnya dibuat
          menjadi matriks data ternormalisasi terbobot (D) dengan cara
          mengalikan setiap elemen dalam matriks normalisasi dengan bobot yang
          telah ditentukan untuk setiap kriteria.
        </p>
      </div>
      <div className="container">
        <table className="table">
          <thead>
            <tr>
              <th>Alternatif</th>
              {weightedMatrix[0].map((_, index) => (
                <th key={index}>C{index + 1}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {weightedMatrix.map((row, rowIndex) => (
              <tr key={rowIndex}>
                <td>{rowIndex === 0 ? "A0" : `A${rowIndex}`}</td> {/* Display A0 for the first row */}
                {row.map((value, colIndex) => (
                  <td key={colIndex}>{value.toFixed(3)}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default NormalisasiTerbobot;



import React from "react";

const MatriksKeputusan = ({ alternatives, criteria, matrix }) => {
  return (
    <div>
      <h3 className="section-title">Matriks Keputusan (X)</h3>
      <div className="container section-description">
      <p className="table-description">
          Langkah awal dalam perhitungan adalah menyusun matriks keputusan (X)
          berdasarkan data yang tersedia. Setiap baris \( i \) merepresentasikan
          alternatif ke-\( i \), dan setiap kolom \( j \) menunjukkan nilai
          kriteria ke-\( j \). Selanjutnya, nilai terbaik untuk setiap kriteria
          ditentukan: nilai tertinggi untuk kriteria *benefit* dan nilai
          terendah untuk kriteria *cost*. Berikut adalah tabel matriks keputusan
          (X) yang telah disusun:
        </p>
        <div className="container"></div>
        <table className="table">
          <thead>
            <tr>
              <th>Alternatif</th>
              {criteria.map((criterion, index) => (
                <th key={index}>{`C${index + 1}`}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {/* Matriks Keputusan untuk Alternatif */}
            {alternatives.map((alternative, rowIndex) => (
              <tr key={rowIndex}>
                <td>{`A${rowIndex}`}</td> {/* Menampilkan kode alternatif */}
                {matrix[rowIndex].map((value, colIndex) => (
                  <td key={colIndex}>{value}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MatriksKeputusan;
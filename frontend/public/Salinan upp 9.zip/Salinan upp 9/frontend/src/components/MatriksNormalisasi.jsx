import React from 'react';

const MatriksNormalisasi = ({ normalizedMatrix }) => {
  return (
    <div>
      <h3 className="section-title">Matriks Normalisasi (R)</h3>
      <div className="container section-description">
        <p className="table-description">
          Setelah matriks keputusan dibuat, selanjutnya adalah membuat matriks
          keputusan yang ternormalisasi R yang fungsinya untuk memperkecil range
          data, dengan tujuan untuk mempermudah perhitungan ARAS dan penghematan
          penggunaan memory.
        </p>
        <div className="container"></div>
        <table className="table">
          <thead>
            <tr>
              <th>Alternatif</th>
              {normalizedMatrix[0].map((_, index) => (
                <th key={index}>{`C${index + 1}`}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {normalizedMatrix.map((row, rowIndex) => (
              <tr key={rowIndex}>
                <td>{`A${rowIndex}`}</td>
                {row.map((value, colIndex) => (
                  <td key={colIndex}>{value.toFixed(3)}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MatriksNormalisasi;
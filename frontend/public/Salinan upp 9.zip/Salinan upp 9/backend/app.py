from flask import Flask, request, jsonify, make_response
from flask_sqlalchemy import SQLAlchemy
from flask_restful import Api, Resource
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash

# Initialize Flask app and configure database
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:@localhost/uupdestination'  # Updated database name
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize database and API
db = SQLAlchemy(app)
api = Api(app)
CORS(app)

# Define database models
class User(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)  # Store hashed password

    def serialize(self):
        return {
            'id': self.id,
            'username': self.username
        }

class Alternatif(db.Model):
    __tablename__ = 'alternatif'
    id = db.Column(db.Integer, primary_key=True)
    kode = db.Column(db.String(10), nullable=False)
    nama = db.Column(db.String(50), nullable=False)
    klasifikasi = db.Column(db.Enum('Berkembang', 'Maju', 'Mandiri'), nullable=False)

    def serialize(self):
        return {
            'id': self.id,
            'kode': self.kode,
            'nama': self.nama,
            'klasifikasi': self.klasifikasi
        }

class Kriteria(db.Model):
    __tablename__ = 'kriteria'
    id = db.Column(db.Integer, primary_key=True)
    kode = db.Column(db.String(10), nullable=False)
    nama = db.Column(db.String(50), nullable=False)
    bobot = db.Column(db.Float, nullable=False)
    tipe = db.Column(db.Enum('Benefit', 'Cost'), nullable=False)

    def serialize(self):
        return {
            'id': self.id,
            'kode': self.kode,
            'nama': self.nama,
            'bobot': self.bobot,
            'tipe': self.tipe
        }

class Penilaian(db.Model):
    __tablename__ = 'penilaian'
    id = db.Column(db.Integer, primary_key=True)
    alternatif_id = db.Column(db.Integer, db.ForeignKey('alternatif.id'), nullable=False)  # Foreign key to Alternatif
    kriteria_id = db.Column(db.Integer, db.ForeignKey('kriteria.id'), nullable=False)  # Foreign key to Kriteria
    kode = db.Column(db.String(10), nullable=False)  # Code (e.g., A1, A2,...)
    C1 = db.Column(db.Integer, nullable=False)
    C2 = db.Column(db.Integer, nullable=False)
    C3 = db.Column(db.Integer, nullable=False)
    C4 = db.Column(db.Integer, nullable=False)
    C5 = db.Column(db.Integer, nullable=False)

    alternatif = db.relationship('Alternatif', backref='penilaian')  # Relationship to Alternatif
    kriteria = db.relationship('Kriteria', backref='penilaian')  # Relationship to Kriteria

    def serialize(self):
        return {
            'id': self.id,
            'alternatif': self.alternatif.nama,  # Use the name of the alternatif
            'kriteria': self.kriteria.nama,  # Use the name of the kriteria
            'kode': self.kode,  # Include the kode in the response
            'C1': self.C1,
            'C2': self.C2,
            'C3': self.C3,
            'C4': self.C4,
            'C5': self.C5
        }

# Resource classes for CRUD operations
class UserResource(Resource):
    def post(self):
        data = request.json
        user = User.query.filter_by(username=data['username']).first()
        if not user or not check_password_hash(user.password, data['password']):
            return make_response(jsonify({'message': 'Invalid credentials'}), 401)
        return jsonify({'message': 'Login successful', 'user': user.serialize()})

class LoginResource(Resource):
    def post(self ):
        data = request.json
        user = User.query.filter_by(username=data['username']).first()
        if not user or not check_password_hash(user.password, data['password']):
            return make_response(jsonify({'message': 'Invalid credentials'}), 401)
        return jsonify({'message': 'Login successful', 'user': user.serialize()})

class AlternatifResource(Resource):
    def get(self, id=None):
        if id:
            alternatif = Alternatif.query.get(id)
            if not alternatif:
                return make_response(jsonify({'message': 'Alternatif not found'}), 404)
            return jsonify(alternatif.serialize())
        alternatif = Alternatif.query.all()
        return jsonify([a.serialize() for a in alternatif])

    def post(self):
        data = request.json
        new_alternatif = Alternatif(
            kode=data['kode'],
            nama=data['nama'],
            klasifikasi=data['klasifikasi']
        )
        db.session.add(new_alternatif)
        db.session.commit()
        return make_response(jsonify({'message': 'Alternatif added successfully'}), 201)

    def delete(self, id):
        alternatif = Alternatif.query.get(id)
        if not alternatif:
            return make_response(jsonify({'message': 'Alternatif not found'}), 404)
        db.session.delete(alternatif)
        db.session.commit()
        return make_response(jsonify({'message': 'Alternatif deleted successfully'}), 200)

    def put(self, id):
        data = request.json
        alternatif = Alternatif.query.get(id)
        if not alternatif:
            return make_response(jsonify({'message': 'Alternatif not found'}), 404)
        alternatif.kode = data['kode']
        alternatif.nama = data['nama']
        alternatif.klasifikasi = data['klasifikasi']
        db.session.commit()
        return make_response(jsonify({'message': 'Alternatif updated successfully'}), 200)

class KriteriaResource(Resource):
    def get(self, id=None):
        if id:
            kriteria = Kriteria.query.get(id)
            if not kriteria:
                return make_response(jsonify({'message': 'Kriteria not found'}), 404)
            return jsonify(kriteria.serialize())
        kriteria = Kriteria.query.all()
        return jsonify([k.serialize() for k in kriteria])

    def post(self):
        data = request.json
        new_kriteria = Kriteria(
            kode=data['kode'],
            nama=data['nama'],
            bobot=data['bobot'],
            tipe=data['tipe']
        )
        db.session.add(new_kriteria)
        db.session.commit()
        return make_response(jsonify({'message': 'Kriteria added successfully'}), 201)

    def delete(self, id):
        kriteria = Kriteria.query.get(id)
        if not kriteria:
            return make_response(jsonify({'message': 'Kriteria not found'}), 404)
        db.session.delete(kriteria)
        db.session.commit()
        return make_response(jsonify({'message': 'Kriteria deleted successfully'}), 200)

class PenilaianResource(Resource):
    def get(self, id=None):
        if id:
            penilaian = Penilaian.query.get(id)
            if not penilaian:
                return make_response(jsonify({'message': 'Penilaian not found'}), 404)
            return jsonify(penilaian.serialize())
        penilaian = Penilaian.query.all()
        return jsonify([p.serialize() for p in penilaian])

    def post(self):
        data = request.json
        required_fields = ['alternatif_id', 'kriteria_id', 'kode', 'C1', 'C2', 'C3', 'C4', 'C5']
        if not all(key in data for key in required_fields):
            return make_response(jsonify({'message': 'Missing data'}), 400)

        alternatif = Alternatif.query.get(data['alternatif_id'])
        kriteria = Kriteria.query.get(data['kriteria_id'])
        if not alternatif or not kriteria:
            return make_response(jsonify({'message': 'Invalid alternatif_id or kriteria_id'}), 400)

        new_penilaian = Penilaian(
            alternatif_id=data['alternatif_id'],
            kriteria_id=data['kriteria_id'],
            kode=data['kode'],
            C1=data['C1'],
            C2=data['C2'],
            C3=data['C3'],
            C4=data['C4'],
            C5=data['C5']
        )
        db.session.add(new_penilaian)
        db.session.commit()
        return make_response(jsonify({'message': 'Penilaian added successfully'}), 201)

    def delete(self, id):
        penilaian = Penilaian.query.get(id)
        if not penilaian:
            return make_response(jsonify({'message': 'Penilaian not found'}), 404)
        db.session.delete(penilaian)
        db.session.commit()
        return make_response(jsonify({'message': 'Penilaian deleted successfully'}), 200)

    def put(self, id):
        data = request.json
        if not all(key in data for key in ['alternatif_id', 'kriteria_id', 'kode', 'C1', 'C2', 'C3', 'C4', 'C5']):
            return make_response(jsonify({'message': 'Missing data'}), 400)

        penilaian = Penilaian.query.get(id)
        if not penilaian:
            return make_response(jsonify({'message': 'Penilaian not found'}), 404)

        alternatif = Alternatif.query.get(data['alternatif_id'])
        kriteria = Kriteria.query.get(data['kriteria_id'])
        if not alternatif or not kriteria:
            return make_response(jsonify({'message': 'Invalid alternatif_id or kriteria_id'}), 400)

        penilaian.alternatif_id = data['alternatif_id']
        penilaian.kriteria_id = data['kriteria_id']
        penilaian.kode = data['kode']
        penilaian.C1 = data['C1']
        penilaian.C2 = data['C2']
        penilaian.C3 = data['C3']
        penilaian.C4 = data['C4']
        penilaian.C5 = data['C5']
        db.session.commit()
        return make_response(jsonify({'message': 'Penilaian updated successfully'}), 200)

# Add routes for resources
api.add_resource(UserResource, '/register')
api.add_resource(LoginResource, '/login')
api.add_resource(AlternatifResource, '/alternatif', '/alternatif/<int:id>')
api.add_resource(KriteriaResource, '/kriteria', '/kriteria/<int:id>')
api.add_resource(PenilaianResource, '/penilaian', '/penilaian/<int:id>')

if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Create all tables
    app.run(debug=True)